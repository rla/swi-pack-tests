name(from_github).
title('Pack installed from GitHub release').
version('0.0.1').
download('http://github.com/user/from_github/archive/v0.0.1.zip').
author('Test pack author', 'pack@example.com').
packager('Test pack author', 'pack@example.com').
maintainer('Test pack author', 'pack@example.com').
home('http://swi-prolog.org').
