:- module(from_github, [
    a_predicate/0
]).

a_predicate:- true.
